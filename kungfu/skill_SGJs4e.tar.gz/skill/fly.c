// fly.c

inherit SKILL;

string type() { return "fly"; }

int valid_learn(object me)
{
    return 1;
}

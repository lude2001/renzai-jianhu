// array.c

inherit SKILL;

string type() { return "knowledge"; }


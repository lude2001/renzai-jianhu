// certosina.c

inherit SKILL;

string type() { return "technic"; }

int valid_learn(object me)
{
    return 1;
}

// xinfa.c

inherit SKILL;


inherit SKILL;


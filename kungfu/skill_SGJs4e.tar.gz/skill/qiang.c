// club.c

inherit SKILL;
int valid_learn(object me) {return 1;}
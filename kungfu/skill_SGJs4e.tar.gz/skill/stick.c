// stick.c
inherit SKILL;

int xyzx_binrun_skill() { return 1; }

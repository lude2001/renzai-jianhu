// literate.c

inherit SKILL;

string type() { return "knowledge"; }

int valid_learn(object me)
{
	return 1;
}
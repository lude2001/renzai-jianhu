// magic.c 符法基础

inherit SKILL;

string type() {return "knowledge"; }

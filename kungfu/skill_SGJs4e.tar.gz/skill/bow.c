// axe.c

inherit SKILL;
